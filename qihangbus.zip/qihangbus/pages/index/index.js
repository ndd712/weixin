// pages/index/index.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
    id1: "back",
    id2: "back",
    id3: "back",
    id4: "back",
    id5: "back",
    id6: "back",
    id7: "back",
    // text:"这是一个页面"
    background: [
      { url: 'http://www.qihangbus.com//Public/images/qhbs/images/index/banner2.png' },
      { url: 'http://www.qihangbus.com//Public/images/qhbs/images/index/banner.png' },
      { url: 'http://www.qihangbus.com//Public/images/qhbs/images/index/banner2.png' },
      { url: 'http://www.qihangbus.com//Public/images/qhbs/images/index/banner.png' },
    ],
    indicatorDots: true,
    vertical: true,
    autoplay: true,
    interval: 3000,
    duration: 800
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  videoErrorCallback: function (e) {
    console.log('视频错误信息:' + e.detail.errMsg);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    var that = this;
    wx.getStorage({
      key: 'userinfo',
      success: function (res) {
        console.log(res.data)
        that.setData({
          info: res.data,
        })
      }
    })

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },
  index_Sign: function () {
    wx.navigateTo({
      url: '../index_Sign/index_Sign'
    })
  },
  index_news: function () {
    wx.navigateTo({
      url: '../index_news/index_news'
    })
  },
  index_changer: function () {
    wx.navigateTo({
      url: '../index_changer/index_changer'
    })
  },
  index_books: function () {
    wx.navigateTo({
      url: '../index_books/index_books'
    })
  },
  index_Freeread: function () {
    wx.navigateTo({
      url: '../index_Freeread/index_Freeread'
    })
  },
  
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})



// pages/index_Sign/index_Sign.js
import {
  getCurrentDate,
  generateDays,
  translateFormateDate,
  nextMonth,
  lastMonth
} from './util'
var app = getApp();  
Page({

  /**
   * 页面的初始数据
   */
  data: {
    flag: true,
    hidden: true,
    date: '2017-05',
    week: ['天', '一', '二', '三', '四', '五', '六'],
    months: [{}]
  }, 
  a: function () {
    this.setData({ flag: false })
  },
  b: function () {
    this.setData({ flag: true })
  },  
  loadingTap: function () {
    this.setData({
      hidden: false
    });
    var that = this;
    setTimeout(function () {
      that.setData({
        hidden: true
      });
      that.update();
    }, 1000);
  },
  /**
   * switch开关监听
   */
  listenerSwitch: function (e) {
    console.log('switch类型开关当前状态-----', e.detail.value);

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
    var currentDate = getCurrentDate()
    this.setData({
      date: currentDate.getYearMonth(),
      dateCN: translateFormateDate(currentDate.getYearMonth()),
      months: generateDays(currentDate.getYearMonth())
    })
  },
  index_changer: function () {
    wx.navigateTo({
      url: '../index_changer/index_changer'
    })
  },
  index_books: function () {
    wx.navigateTo({
      url: '../index_books/index_books'
    })
  },
  bindPickerChange: function (e) {
    this.setData({
      months: generateDays(e.detail.value),
      date: e.detail.value,
      dateCN: translateFormateDate(e.detail.value)
    })
  },

  bindNextMonth: function () {
    this.setData({
      date: nextMonth(this.data.date),
      dateCN: translateFormateDate(nextMonth(this.data.date)),
      months: generateDays(nextMonth(this.data.date))
    })
  },

  bindLastMonth: function () {
    this.setData({
      date: lastMonth(this.data.date),
      dateCN: translateFormateDate(lastMonth(this.data.date)),
      months: generateDays(lastMonth(this.data.date))
    })
  },

  click: function (e) {
    console.log('今日签到'),
    console.log(e.currentTarget.dataset.item)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
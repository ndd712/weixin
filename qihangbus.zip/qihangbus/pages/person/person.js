// pages/person/person.js
Page({
  /**
   * 页面的初始数据
   */
  data: {
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this;
    wx.getStorage({
      key: 'userinfo',
      success: function (res) {
        console.log(res.data.paid_time)
        that.setData({
          info: res.data,
        })
        
      }
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },
  person_borrow: function () {
    wx.navigateTo({
      url: '../person_borrow/person_borrow'
    })
  },
  person_myorders: function () {
    wx.navigateTo({
      url: '../person_myorders/person_myorders'
    })
  },
  person_shoppingcart: function () {
    wx.navigateTo({
      url: '../person_shoppingcart/person_shoppingcart'
    })
  },
  person_myearnings: function () {
    wx.navigateTo({
      url: '../person_myearnings/person_myearnings'
    })
  },
address: function () {
    wx.navigateTo({
      url: '../person/address'
    })
  },
  person_Accountmanagement: function () {
    wx.navigateTo({
      url: '../person_Accountmanagement/person_Accountmanagement'
    })
  },
  person_grade:function() {
  wx.navigateTo({
    url: '../person_grade/person_grade'
  })
  },
  person_password: function () {
    wx.navigateTo({
      url: '../person_password/person_password'
    })
  },
  person_logonlogon: function () {
    wx.navigateTo({
      url: '../person_logonlogon/person_logonlogon'
    })
  },
  
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  },
  clickButton:function(event){
    console.log(event.target.id);
    var data = this.data.screenData + event.target.id;
    this.setData({screenData:data});
  }
})
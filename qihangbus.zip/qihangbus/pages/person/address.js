// pages/person/address.js
var app = getApp();
var common = require('../../utils/util.js');
var address = {
  "code": 200,
  "requestId": "",
  "data": [
    {
      recipient: "小高",
      telephone: 13219954391,
      province: "郑州",
      city: "郑州市",
      area: "郑东新区",
      address: "商务外环路27号",
      isDefault: 0
    },
    {
      recipient: "小静",
      telephone: 13519991234,
      province: "北京",
      city: "北京市",
      area: "海淀区",
      address: "知春路东大街",
      isDefault: 1
    }
  ],
  "success": true,
  "message": "success"
}
Page({
  data: {},
  onLoad: function () {

  },
  onShow: function () {
    var self = this,
    data = address.data;
    self.setData({
    address: data
    })
  },
  setDefault: function (e) {
    var self = this,
      bindVal = e.currentTarget.dataset.value.index;
  },
  delAddr: function (e) {
    var id = e.currentTarget.dataset.id;
    wx.request({

      url: '../person/address/delAddress?id=' + id,

      data: {},

      method: 'GET',

      success: function (res) {

        if (res.data.status == 0) {

          wx.showToast({

            title: res.data.info,

            icon: 'loading',

            duration: 1500

          })

        } else {

          wx.showToast({

            title: res.data.info,

            icon: 'success',

            duration: 1000

          })

          //删除之后应该有一个刷新页面的效果，等和其他页面刷新跳转一起做

        }

      },
      fail: function () {

        wx.showToast({

          title: '服务器网络错误!',

          icon: 'loading',

          duration: 1500

        })
      }
    })
  },
  editAddr: function (e) {
    var id = e.currentTarget.dataset.id;
    wx.navigateTo({
      url: "editAddr?id=" + id,
      success: function (res) {
      },
    })
  },
  addAddr: function (e) {
    wx.navigateTo({
      url: "editAddr",
      success: function (res) {
      },
    })
  }

})
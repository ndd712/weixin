// pages/Perfect_information/Perfect_information.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    // 普通选择器列表设置,及初始化 学校选择
    countryList: ['伊顿幼儿园', '嘉贝幼儿园', '常春藤幼儿园', '海文国际幼儿园', '郑东新区实验幼儿园', '伯利恒国际幼儿学校', '思璞国际幼儿园', '木子国际幼稚园', '北大学园幼儿园','蓝天幼儿园'],
    countryIndex: 10,
    // 年级选择
    countryList1: ['大班', '中班', '小班'],
    countryIndex1: 3,
    // 班级选择
    countryList2: ['一班', '二班', '三班'],
    countryIndex2: 3,
    // 省市区三级联动初始化
    region: ["河南省", "郑州市", "郑东新区"],
    // 多列选择器(三级联动)列表设置,及初始化
    multiArray3: [[1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 2, 3, 4, 5, 6, 7, 8, 9]],
    multiIndex3: [3, 5, 4]
  },
  // 选择学校函数
  changeCountry(e) {
    this.setData({ countryIndex: e.detail.value });
  },
  // 选择年级函数
  changeCountry1(e) {
    this.setData({ countryIndex1: e.detail.value });
  },
  // 选择班级函数
  changeCountry2(e) {
    this.setData({ countryIndex2: e.detail.value });
  },
  // 选择省市区函数
  changeRegin(e) {
    this.setData({ region: e.detail.value });
  },
  // 选择三级联动
  changeMultiPicker3(e) {
    this.setData({ multiIndex3: e.detail.value })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})
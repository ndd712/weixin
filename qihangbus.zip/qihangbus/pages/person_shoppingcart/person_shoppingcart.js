// pages/person_shoppingcart/person_shoppingcart.js
Page({
  data: {
    carts: [
      { cid: 1008, title: '正版 伊娃和丽萨暖绘本精装 部分地区包邮幼少儿童情商成长...', image: 'http://www.qihangbus.com//Public/images/qhbs/images/person/book1.png', title1: '限购5本', num: '1', price: '23.8', sum: '￥23.8', selected: true },
      { cid: 1012, title: '手指 嗖 启发一本集手指游戏、洞洞书、恐龙科普三位一位的...', image: 'http://www.qihangbus.com//Public/images/qhbs/images/person/book3.png', title1: '限购5本', num: '1', price: '23.5', sum: '￥23.5', selected: true },
      { cid: 1031, title: '我不怕打针', image: 'http://www.qihangbus.com//Public/images/qhbs/images/person/book2.png', title1: '限购5本', num: '1', price: '22.4', sum: '￥22.4', selected: true },
    ],
    minusStatuses: ['disabled', 'disabled', 'normal', 'normal', 'disabled'],
    selectedAllStatus: true,
    total: ''

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.sum();

  },
  // 数量 最小
  bindMinus: function (e) {
    var index = parseInt(e.currentTarget.dataset.index);
    var num = this.data.carts[index].num;
    // 如果只有1件了，就不允许再减了
    if (num > 1) {
      num--;
    }
    // 只有大于一件的时候，才能normal状态，否则disable状态
    var minusStatus = num <= 1 ? 'disabled' : 'normal';
    // 购物车数据
    var carts = this.data.carts;
    carts[index].num = num;
    // 按钮可用状态
    var minusStatuses = this.data.minusStatuses;
    minusStatuses[index] = minusStatus;
    // 将数值与状态写回
    this.setData({
      carts: carts,
      minusStatuses: minusStatuses
    });
    this.sum()
  },
  // 数量 最大
  bindPlus: function (e) {
    var index = parseInt(e.currentTarget.dataset.index);
    var num = this.data.carts[index].num;
    // 自增
    num++;
    // 只有大于一件的时候，才能normal状态，否则disable状态
    var minusStatus = num <= 1 ? 'disabled' : 'normal';
    // 购物车数据
    var carts = this.data.carts;
    carts[index].num = num;
    // 按钮可用状态
    var minusStatuses = this.data.minusStatuses;
    minusStatuses[index] = minusStatus;
    // 将数值与状态写回
    this.setData({
      carts: carts,
      minusStatuses: minusStatuses
    });
    this.sum()
  },
  bindCheckbox: function (e) {

    /*绑定点击事件，将checkbox样式改变为选中与非选中*/
    //拿到下标值，以在carts作遍历指示用
    var index = parseInt(e.currentTarget.dataset.index);
    //原始的icon状态
    var selected = this.data.carts[index].selected;
    var carts = this.data.carts;
    // 对勾选状态取反
    carts[index].selected = !selected;
    // 环境中目前已选状态
    var selectedAllStatus = this.data.selectedAllStatus;
    console.log(selectedAllStatus)
    // 遍历存在非选中的时候，取消选中
    // 遍历
    var flag = true;
    for (var i = 0; i < carts.length; i++) {
      if (carts[i].selected == false) {
        flag = false;
        // 取反操作
        // selectedAllStatus = false;
      }
    }

    selectedAllStatus = flag;

    // 写回经点击修改后的数组
    this.setData({
      carts: carts,
      selectedAllStatus: selectedAllStatus
    });



    this.sum();

  },
  bindSelectAll: function () {
    // 环境中目前已选状态
    var selectedAllStatus = this.data.selectedAllStatus;
    // 取反操作
    selectedAllStatus = !selectedAllStatus;
    // 购物车数据，关键是处理selected值
    var carts = this.data.carts;
    // 遍历
    for (var i = 0; i < carts.length; i++) {
      carts[i].selected = selectedAllStatus;
    }
    this.setData({
      selectedAllStatus: selectedAllStatus,
      carts: carts
    });
    this.sum()
  },
  // 结算总价格
  bindCheckout: function () {

    // 初始化toastStr字符串
    var toastStr = 'cid:';
    // 遍历取出已勾选的cid
    for (var i = 0; i < this.data.carts.length; i++) {
      if (this.data.carts[i].selected) {
        toastStr += this.data.carts[i].cid;
        toastStr += ' ';
      }
    }
    //存回data
    this.setData({
      toastHidden: false,
      toastStr: toastStr
    });
  },
  bindToastChange: function () {
    this.setData({
      toastHidden: true
    });

  },
  sum: function () {
    var carts = this.data.carts;
    // 计算总金额
    var total = 0;
    for (var i = 0; i < carts.length; i++) {
      if (carts[i].selected) {
        total += carts[i].num * carts[i].price;
      }
    }
    // 写回经点击修改后的数组
    this.setData({
      carts: carts,
      total: '￥' + total
    });
  }
})



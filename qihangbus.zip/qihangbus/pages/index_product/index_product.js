// pages/index_product/index_product.js
var book_id=null;
var student_id=null;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    isLike: true,
    // banner
    imgUrls: [
      "http://www.qihangbus.com/{{info['book_img']}}",
      "http://www.qihangbus.com/{{info['book_img']}}",
      "http://www.qihangbus.com/{{info['book_img']}}",
      "http://www.qihangbus.com/{{info['book_img']}}"
    ],
    indicatorDots: true, //是否显示面板指示点
    autoplay: true, //是否自动切换
    interval: 3000, //自动切换时间间隔,3s
    duration: 1000, //  滑动动画时长1s
  },

  //预览图片
  previewImage: function (e) {
    var current = e.target.dataset.src;

    wx.previewImage({
      current: current, // 当前显示图片的http链接  
      urls: this.data.imgUrls // 需要预览的图片http链接列表  
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    wx.getStorage({
      key: 'userinfo',
      success: function (res) {
        book_id = res.data.book_info[options.id].book_id;
        student_id = res.data.student_id;
        console.log(res.data)
        that.setData({
          info: res.data.book_info[options.id],
        })
      }
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },
  addborrow: function(){
    console.log(book_id);
    console.log(student_id);
    wx.request({
      url: 'https://www.qihangbus.com/xiaochengxu.php/Parentlogin/addtoborrrw',
      data: {
        type: "borrow",
        book_id: info,
      },
      method: "post",
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      success: function (res) {
        console.log(res.data)
        if (res.data) {
          wx.showToast({
            title: '借阅成功',
            icon: 'success',
            duration: 1000,
          });
        } else {
          wx.showToast({
            title: '借阅失败',
            icon: 'false',
            duration: 1000,
          });
        }
      }
    })
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})
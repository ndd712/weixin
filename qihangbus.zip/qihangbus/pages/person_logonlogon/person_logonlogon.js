// pages/person_logonlogon/person_logonlogon.js
var type = null;
var mobile = null;
var pwd = null;
Page({
  onLaunch: function () {
    wx.login({
      success: function (res) {
        var code = res.code;
        if (code) {
          console.log('获取用户登录凭证：' + code);
        } else {
          console.log('获取用户登录态失败：' + res.errMsg);
        }
      }
    });
  },
  data: {
    phone: '',
    password: ''
  },
  /**
  * checkbox类型开关监听
  */
  listenerCheckboxSwitch: function (e) {
    console.log('checkbox类型开关当前状态-----', e.detail.value)
    type = e.detail.value
  },
  onLoad: function (options) {
    // 页面初始化 options为页面跳转所带来的参数
  },
  onReady: function () {
    // 页面渲染完成
  },
  onShow: function () {
    // 页面显示
  },
  onHide: function () {
    // 页面隐藏
  },
  onUnload: function () {
    // 页面关闭
  },

  // 获取输入账号  
  phoneInput: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },

  // 获取输入密码  
  passwordInput: function (e) {
    this.setData({
      password: e.detail.value,
    })
  },

  // 登录  
  login: function () {
    pwd = this.data.password
    mobile = this.data.phone
    // console.log(mobile);
    // console.log(pwd);
    if (this.data.phone.length < 11 || this.data.password.length == 0) {
      wx.showToast({
        title: '用户名和密码不能为空',
        icon: 'loading',
        duration: 2000
      })
    } else {
      if (type) {
        // 这里修改成跳转的页面  
        wx.request({
          url: 'https://www.qihangbus.com/xiaochengxu.php/Parentlogin/validate_code',
          data: {
            type: "login",
            mobile: this.data.phone,
            password: this.data.password,
          },
          method: "post",
          header: {
            'content-type': 'application/x-www-form-urlencoded'
          },
          success: function (res) {
            console.log(res.data)
            if (res.data) {
              wx.showToast({
                title: '登录成功',
                icon: 'success',
                duration: 1000,
                complete: function () {
                  setTimeout(function () {
                      wx.switchTab({
                        url: '../index/index',
                        success: function(res) {},
                        fail: function(res) {},
                        complete: function(res) {},
                      })
                  }, 1000)
                }
              });
              try {
                wx.setStorageSync('userinfo', res.data)
              } catch (e) {
              }
            }else{
              wx.showToast({
                title: '登录失败',
                icon: 'false',
                duration: 1000,
              });
            }
          }
        })
      } else {
        wx.showToast({
          title: '请先阅读协议',
          icon: 'loading',
          duration: 2000
        })
      }
    }
  }

})  
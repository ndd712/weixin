var apiPrefix = 'https://api.weixin.qq.com/';

var config = {
    static: {
      imageDomain: 'https://api.weixin.qq.com/'
    },
    api: {
        reqCategoryList: '/categories',
        reqProductList: '/products',
        reqProductDetail: '/product/:id'
    }
};

for (var key in config.api) {
    config.api[key] = apiPrefix + config.api[key];
}

module.exports = config;